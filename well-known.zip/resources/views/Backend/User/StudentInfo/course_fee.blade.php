<!-- @if($total_value) -->
<div class="input-single-box">
    <label>Course Fee</label>
    <input type="text" name="fee" class="form-control" readonly id="main_fee" value="{{$total_value}}">
</div>
<!-- @endif -->