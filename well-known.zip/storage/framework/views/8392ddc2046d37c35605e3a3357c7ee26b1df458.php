
<?php $__env->startSection('body'); ?>
<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<!-- <i class="feather icon-home bg-c-blue"></i> -->
<div class="d-inline">
<h5>Add Student</h5>
<!-- <span>This Is SBIT Dashboard</span> -->
<div class="links" style="margin-top: 20px;">
    <a href="<?php echo e(url('viewStudent')); ?>" class="btn btn-outline-info">View Student</a>
</div>
</div>
</div>
</div>

</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">
 
 <!-- //body content goes here -->
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>Add Student</h5>
        </div>
        <div class="card-block">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('success')); ?></strong>
                </div>
                <?php elseif(Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('error')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($data): ?>
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('/studentUpdate')); ?>/<?php echo e($data->id); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Date (YYYY/MM/DD)</label>
                            <input name="date" class="form-control" type="text" required value="<?php echo e($data->date); ?>" id="dateTimePicker">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Student Type</label><br>
                            <select class="form-control" name="type" required>
                                <?php if($data->type == 'Regular'): ?>
                                <option selected value="Regular">Regular</option>
                                <option value="Industrial">Industrial</option>
                                <?php elseif($data->type == 'Industrial'): ?>
                                <option value="Regular">Regular</option>
                                <option selected value="Industrial">Industrial</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="card-header col-12">
                         <h5>Student Personal Information</h5>
                    </div>

                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Student Name</label>
                            <input type="text" name="name" class="form-control" required value="<?php echo e($data->name); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Fathers Name</label>
                            <input type="text" name="fathers_name" class="form-control" required value="<?php echo e($data->fathers_name); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Mothers Name</label>
                            <input type="text" name="mothers_name" class="form-control" required value="<?php echo e($data->mothers_name); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Gender</label><br>
                            <select class="form-control" name="gender">
                                <?php if($data->gender == 'Male'): ?>
                                <option selected value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Others">Others</option>
                                <?php elseif($data->gender == 'Female'): ?>
                                <option value="Male">Male</option>
                                <option selected value="Female">Female</option>
                                <option value="Others">Others</option>
                                <?php elseif($data->gender == 'Others'): ?>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option selected value="Others">Others</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Nationality</label>
                            <input type="text" name="nationality" class="form-control" value="<?php echo e($data->nationality); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Religion</label>
                            <select class="form-control" name="religion">
                                <?php if($data->religion == 'Islam'): ?>
                                <option selected value="Islam">Islam</option>
                                <option value="Hindu">Hindu</option>
                                <option value="Buddist">Buddist</option>
                                <option value="Chiristian">Chiristian</option>
                                <?php elseif($data->religion == 'Hindu'): ?>
                                <option value="Islam">Islam</option>
                                <option selected value="Hindu">Hindu</option>
                                <option value="Buddist">Buddist</option>
                                <option value="Chiristian">Chiristian</option>
                                <?php elseif($data->religion == 'Buddist'): ?>
                                <option value="Islam">Islam</option>
                                <option value="Hindu">Hindu</option>
                                <option selected value="Buddist">Buddist</option>
                                <option value="Chiristian">Chiristian</option>
                                <?php elseif($data->religion == 'Chiristian'): ?>
                                <option value="Islam">Islam</option>
                                <option value="Hindu">Hindu</option>
                                <option value="Buddist">Buddist</option>
                                <option selected value="Chiristian">Chiristian</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Insititute Name</label>
                            <input type="text" name="institute" class="form-control" value="<?php echo e($data->institute); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Technology/Group</label>
                            <input type="text" name="group" class="form-control" value="<?php echo e($data->group); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Semister/Year</label>
                            <input type="text" name="semister" class="form-control" value="<?php echo e($data->semister); ?>">
                        </div>
                    </div>
                    <div class="card-header col-12">
                         <h5>Student Contact Information</h5>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" required value="<?php echo e($data->phone); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e($data->email); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>District</label>
                            <input type="text" name="district" class="form-control" required value="<?php echo e($data->district); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Upazila</label>
                            <input type="text" name="upazila" class="form-control" value="<?php echo e($data->upazila); ?>">
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="input-single-box">
                            <label>Adress</label>
                            <textarea class="form-control" name="adress"><?php echo e($data->adress); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Image</label>
                            <input type="file" name="image" class="form-control">
                            <img src="<?php echo e(asset('public/public/Backend')); ?>/images/studentImage/<?php echo e($data->image); ?>" height="70px" width="70px" style="border-radius:100px;">
                        </div>
                    </div>
                    <div class="card-header col-12">
                         <h5>Student Course Information</h5>
                    </div>
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="input-single-box">
                            <label><h3>Select Course</h3></label><br>
                            <?php if($course): ?>
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $course_id = DB::table('student_course_info')
                                         ->where('course_id',$showcourse->id)
                                         ->where('student_id',$data->id)
                                         ->pluck('course_id')
                                         ->first();

                            ?>
                            <div class="checkbox-fade fade-in-primary">
                                <label>
                                <input  onclick="courseFee(<?php echo e($showcourse->id); ?>)" id="course_id-<?php echo e($showcourse->id); ?>" type="checkbox" value="<?php echo e($showcourse->id); ?>" name="course_id[]" <?php if($course_id == $showcourse->id): ?> checked <?php endif; ?>>
                                <span class="cr">
                                <i class="cr-icon icofont icofont-ui-check txt-primary"></i>
                                </span>
                                <span><?php echo e($showcourse->course_name); ?></span>
                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12" id="fee">
                        <div class="input-single-box">
                            <label>Course Fee</label>
                            <input type="text" name="main_fee" class="form-control" id="main_fee" value="<?php echo e($data->main_fee); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Discount</label>
                            <input type="text" name="discount" class="form-control" onkeyup="discount()" id="discount_ammount" value="<?php echo e($data->discount); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Discount Percentage</label>
                            <input type="text" name="discount_per" class="form-control" readonly id="discount_per" value="<?php echo e($data->discount_per); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Total Ammount</label>
                            <input type="text" name="total_fee" class="form-control" id="total_fee" value="<?php echo e($data->total_fee); ?>">
                        </div>
                    </div>

                    <div class="card-header col-12">
                         <h5>Student Class Time</h5>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Join Date (YYYY/MM/DD)</label>
                            <input name="join_date" class="form-control" type="text" placeholder="Select your Date" required value="<?php echo e($data->join_date); ?>" id="dateTimePicker1">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="input-single-box">
                            <label>Class Time</label>
                            <select class="form-control" name="class_time">
                                <?php if($data->class_time == 'Morning'): ?>
                                <option selected value="Morning">Morning</option>
                                <option value="Afternoon">Afternoon</option>
                                <?php elseif($data->class_time == 'Afternoon'): ?>
                                <option value="Morning">Morning</option>
                                <option selected value="Afternoon">Afternoon</option>
                                <?php endif; ?>
                                
                            </select>
                        </div>
                    </div>
                </div>
                <input type="text" name="admin_id" class="form-control" value="<?php echo e(Auth()->user()->id); ?>" hidden>
                <div class="input-single-box" style="text-align: center;">
                    <input type="submit" name="submit" class="btn btn-success btn-block">
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div> 
 </div>
 <!-- //body content goes here -->

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skillbasedit/public_html/accounts/resources/views/Backend/User/StudentInfo/edit_student.blade.php ENDPATH**/ ?>