<?php if($data): ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($sl++); ?></td>
    <td><?php echo $showdata->description; ?></td>
    <td><?php echo e($showdata->ammount); ?></td>
    <td>
        <button class="btn btn-outline-danger" id="deleteCurrent_<?php echo e($showdata->id); ?>" name="<?php echo e($showdata->id); ?>" onclick="DeleteCurrent(<?php echo e($showdata->id); ?>)">Remove</button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- <tr>
    <td colspan="2" style="text-align:right">Total</td>
    <td colspan="2"><u><b><?php echo e($total); ?></b></u></td>
</tr> -->

<?php endif; ?><?php /**PATH /home/skillbasedit/public_html/accounts/resources/views/Backend/User/Bill/get_current_data.blade.php ENDPATH**/ ?>