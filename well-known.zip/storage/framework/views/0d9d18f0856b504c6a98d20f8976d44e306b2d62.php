
<?php $__env->startSection('body'); ?>
<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<!-- <i class="feather icon-home bg-c-blue"></i> -->
<div class="d-inline">
<h5>View Student</h5>
<!-- <span>This Is SBIT Dashboard</span> -->
<div class="links" style="margin-top: 20px;">
    <a href="<?php echo e(url('addStudent')); ?>" class="btn btn-outline-info">Add Student</a>
</div>
</div>
</div>
</div>

</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">
 
 <!-- //body content goes here -->
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>View Student</h5>
        </div>
        <div class="card-block">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('success')); ?></strong>
                </div>
                <?php elseif(Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('error')); ?></strong>
                </div>
                <?php endif; ?>

            <div class="dt-responsive table-responsive">
                <table class="table table-striped table-bordered nowrap dataTable" id="order-table">
                    <thead>
                        <tr>
                            <!-- <th>Select</th> -->
                            <th>Sl</th>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Fathers Name</th>
                            <th>Mothers Name</th>
                            <th>Gender</th>
                            <th>Nationality</th>
                            <th>Religion</th>
                            <th>Institute Name</th>
                            <th>Technology/Group</th>
                            <th>Semister/Year</th>
                            <th>Student Type</th>
                            <th>Course</th>
                            <th>Course Fee</th>
                            <th>Discount Fee</th>
                            <th>Discount Percantage(%)</th>
                            <th>Total Ammount</th>
                            <th>Paid</th>
                            <th>Due</th>
                            <th>Join Date</th>
                            <th>Class Time</th>
                            <th>image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td><input type="checkbox" name="id[]" value="<?php echo e($showdata->id); ?>"></td> -->
                            <td><?php echo e($sl++); ?></td>
                            <td><?php echo e($showdata->unique_id); ?></td>
                            <td><?php echo e($showdata->name); ?></td>
                            <td><?php echo e($showdata->fathers_name); ?></td>
                            <td><?php echo e($showdata->mothers_name); ?></td>
                            <td><?php echo e($showdata->gender); ?></td>
                            <td><?php echo e($showdata->nationality); ?></td>
                            <td><?php echo e($showdata->religion); ?></td>
                            <td><?php echo e($showdata->institute); ?></td>
                            <td><?php echo e($showdata->group); ?></td>
                            <td><?php echo e($showdata->semister); ?></td>
                            <td><?php echo e($showdata->type); ?></td>
                            <td>
                                <?php
                                $course = DB::table('student_course_info')
                                          ->where('student_id',$showdata->id)
                                          ->join('course_infos','course_infos.id','=','student_course_info.course_id')
                                          ->select('course_infos.course_name','student_course_info.status')
                                          ->get();  
                                ?>
                                <?php if($course): ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($showcourse->course_name); ?> <?php if($showcourse->status == '1'): ?><span  class="badge badge-success">Completed</span> <?php endif; ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($showdata->main_fee); ?></td>
                            <td><?php echo e($showdata->discount); ?></td>
                            <td><?php echo e($showdata->discount_per); ?></td>
                            <td><?php echo e($showdata->total_fee); ?></td>
                            <td><div style="font-size: 20px;" class="badge badge-success"><?php echo e($showdata->paid); ?></div></td>
                            <td><div style="font-size: 20px;" class="badge badge-danger"><?php echo e($showdata->due); ?></div></td>
                            <td><?php echo e($showdata->join_date); ?></td>
                            <td><?php echo e($showdata->class_time); ?></td>
                            <td>
                                <?php if(file_exists($showdata->image)): ?>
                                <img src="<?php echo e(asset('public/public/Backend')); ?>/Images/studentImage/<?php echo e($showdata->image); ?>" height="70px" width="70px" style="border-radius:100px;">
                                <?php endif; ?>
                            </td>
                            <td>
                                <a target="blank" href="<?php echo e(url('showForm')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-secondary">Show Form</a>
                                <a href="<?php echo e(url('editStudent')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-info">Edit</a>
                                <a href="<?php echo e(url('deleteStudent')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-danger">Delete</a>
                                <a href="<?php echo e(url('details')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-secondary">Details</a><br>
                                <a target="blank" href="<?php echo e(url('id_card')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-warning">Get ID Card</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
 </div>
 <!-- //body content goes here -->

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skillbasedit/public_html/accounts/resources/views/Backend/User/StudentInfo/view_student.blade.php ENDPATH**/ ?>