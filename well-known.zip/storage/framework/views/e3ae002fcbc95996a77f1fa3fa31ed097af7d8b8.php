
<?php $__env->startSection('body'); ?>
<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<!-- <i class="feather icon-home bg-c-blue"></i> -->
<div class="d-inline">
<h5>Add Trainer</h5>
<!-- <span>This Is SBIT Dashboard</span> -->
<div class="links" style="margin-top: 20px;">
    <a href="<?php echo e(url('viewTrainer')); ?>" class="btn btn-outline-info">View Trainer</a>
</div>
</div>
</div>
</div>

</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">
 
 <!-- //body content goes here -->
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>Add Trainer</h5>
        </div>
        <div class="card-block">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('success')); ?></strong>
                </div>
                <?php elseif(Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('error')); ?></strong>
                </div>
                <?php endif; ?>
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('/trainerStore')); ?>">
                <?php echo csrf_field(); ?>
                <!-- <div class="input-single-box">
                    <label>Serial No</label>
                    <input type="text" name="sl" class="form-control" value="<?php echo e(old('sl')); ?>">
                </div> -->
                <div class="input-single-box">
                    <label>Select Course</label>
                    <select class="form-control" name="course_id">
                        <?php if($course): ?>
                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($showcourse->id); ?>"><?php echo e($showcourse->course_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="input-single-box">
                    <label>Trainer Name</label>
                    <input type="text" name="trainer_name" class="form-control" value="<?php echo e(old('trainer_name')); ?>">
                </div>
                <div class="input-single-box">
                    <label>Trainer Phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
                </div>
                <div class="input-single-box">
                    <label>Trainer Designation</label>
                    <input type="text" name="designation" class="form-control" value="<?php echo e(old('designation')); ?>">
                </div>
                <div class="input-single-box">
                    <label>Trainer Salary</label>
                    <input type="number" name="salary" class="form-control" value="<?php echo e(old('salary')); ?>">
                </div>
                <div class="input-single-box">
                    <label>Adress</label>
                    <textarea class="form-control" name="adress"></textarea>
                </div>
                <div class="input-single-box">
                    <label>Status</label>
                    <select class="form-control" name="status"> 
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
                <div class="input-single-box">
                    <label>Image</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <input type="text" name="admin_id" class="form-control" value="<?php echo e(Auth()->user()->id); ?>" hidden>
                <div class="input-single-box">
                    <input type="submit" name="submit" class="btn btn-success">
                </div>
            </form>
        </div>
    </div> 
 </div>
 <!-- //body content goes here -->

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skillbasedit/public_html/accounts/resources/views/Backend/User/TrainerInfo/add_trainer.blade.php ENDPATH**/ ?>