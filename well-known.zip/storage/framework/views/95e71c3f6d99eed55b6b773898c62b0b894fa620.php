
<?php $__env->startSection('body'); ?>
<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<!-- <i class="feather icon-home bg-c-blue"></i> -->
<div class="d-inline">
<h5>Add Income Title</h5>
<!-- <span>This Is SBIT Dashboard</span> -->
</div>
</div>
</div>

</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">
 
 <!-- //body content goes here -->
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>Add Income Title</h5>
        </div>
        <div class="card-block">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('success')); ?></strong>
                </div>
                <?php elseif(Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('error')); ?></strong>
                </div>
                <?php endif; ?>
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('/incomeTitleStore')); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-single-box">
                    <label>Serial No</label>
                    <input type="text" name="sl" class="form-control" value="<?php echo e(old('sl')); ?>">
                </div>
                <div class="input-single-box">
                    <label>Title Name</label>
                    <input type="text" name="income_title" class="form-control" value="<?php echo e(old('income_title')); ?>">
                </div>
                <div class="input-single-box">
                    <label>Status</label>
                    <select class="form-control" name="status"> 
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
                <input type="text" name="admin_id" class="form-control" value="<?php echo e(Auth()->user()->id); ?>" hidden>
                <div class="input-single-box">
                    <input type="submit" name="submit" class="btn btn-success">
                </div>
            </form>
        </div>
    </div>
 </div>
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>View Income Title</h5>
        </div>
        <div class="card-block">
            <div class="dt-responsive table-responsive">
                <table class="table table-striped table-bordered nowrap dataTable" id="order-table">
                    <thead>
                        <tr>
                            <th>Sl</th>
                            <th>Title Namex</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($showdata->sl); ?></td>
                            <td><?php echo e($showdata->income_title); ?></td>
                            <td>
                                <?php if($showdata->status == '1'): ?>
                                <div class="badge badge-success">Active</div>
                                <?php else: ?>
                                <div class="badge badge-danger">Inactive</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('editIncomeTitle')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-info">Edit</a>
                                <?php if($showdata->id == 1000): ?>
                                
                                <?php else: ?>
                                <a href="<?php echo e(url('deleteIncomeTitle')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-danger">Delete</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 </div>
 <!-- //body content goes here -->

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/User/IncomeInfo/add_income_title.blade.php ENDPATH**/ ?>