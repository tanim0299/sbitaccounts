<div id="styleSelector">
</div>

</div>
</div>
</div>
</div>





<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/bootstrap/js/bootstrap.min.js"></script>

<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/waves/js/waves.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>

<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/chart/float/jquery.flot.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/chart/float/jquery.flot.categories.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/chart/float/curvedLines.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/chart/float/jquery.flot.tooltip.min.js"></script>

<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/widget/amchart/amcharts.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/widget/amchart/serial.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/widget/amchart/light.js"></script>

<script src="../../../developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/google-maps/gmaps.js"></script>

<script src="<?php echo e(asset('public/Backend')); ?>/assets/js/pcoded.min.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/assets/js/vertical/vertical-layout.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/dashboard/crm-dashboard.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/js/script.min.js"></script>

<!-- datatables -->
<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>

<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('public/Backend')); ?>/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<script src="<?php echo e(asset('public/Backend')); ?>/assets/pages/data-table/js/data-table-custom.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/advance-elements/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/bootstrap-daterangepicker/js/daterangepicker.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/datedropper/js/datedropper.min.js"></script>


<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/spectrum/js/spectrum.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/jscolor/js/jscolor.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/jquery-minicolors/js/jquery.minicolors.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/advance-elements/custom-picker.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/advance-elements/custom-picker1.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/advance-elements/custom-picker2.js"></script>



<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/modernizr/js/css-scrollbars.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/switchery/js/switchery.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/bootstrap-tagsinput/js/bootstrap-tagsinput.js"></script>
<!-- <script src="../../../cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.10.4/typeahead.bundle.min.js"></script> -->

<!-- <script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/bower_components/bootstrap-maxlength/js/bootstrap-maxlength.js"></script> -->

<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/pages/advance-elements/swithces.js"></script>
<!-- <script src="<?php echo e(asset('public/Backend')); ?>/assets/js/pcoded.min.js"></script> -->
<!-- <script src="<?php echo e(asset('public/Backend')); ?>/assets/js/vertical/vertical-layout.min.js"></script> -->
<script src="<?php echo e(asset('public/Backend')); ?>/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Backend')); ?>/assets/js/script.js"></script>



<script src="https://cdn.jsdelivr.net/npm/uikit@3.14.3/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.14.3/dist/js/uikit-icons.min.js"></script>




<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('public')); ?>/Backend/js/dtsel.js"></script>

<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>




<!-- <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script> -->

<script type="text/javascript">
    
   function courseFee(id)
   {
   	$("#course_id-"+id).on('change',function(){
        $('#discount_ammount').val(0);
   		var id = $(this).val();

   		var presentValue = $("#main_fee").val();

   		// var default = 

   		if($('#course_id-'+id).is(':checked'))
   		{
   			$.ajax({

   				headers : {
                    'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                },

                url : '<?php echo e(url('getCourseFee')); ?>',

                type : 'POST',

                data : {

                    id : id,p_value:presentValue
                },

                success : function(data)
                {
                	$('#main_fee').val(data);
                    $('#total_fee').val(data);
                } 
   		});


   		}
   		else if($('#course_id-'+id).is(':not(:checked)'))
   		{
   			// $("#fee").html("Please Select A Course");
   			$.ajax({

   				headers : {
                    'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                },

                url : '<?php echo e(url('subCourseFee')); ?>',

                type : 'POST',

                data : {

                    id : id,p_value:presentValue
                },

                success : function(data)
                {
                	$('#main_fee').val(data);
                    $('#total_fee').val(data);
                } 
   		});

   		}
   		else
   		{
   			$("#fee").html(data);
   		}


   		// alert(id);
   	});


   }

   
   $(document).ready(function(){


    $("#discount_ammount").on('keyup',function(){

        var discount_ammount = parseInt($(this).val());

        var main_fee = parseInt($("#main_fee").val());

        // alert(main_fee);

        if(discount_ammount > main_fee)
        {
            UIkit.notification({
                message: 'Invalid Discount Ammount!',
                status: 'primary',
                pos: 'top-right',
                timeout: 5000
            });
            $("#discount_ammount").val(0);
            $("#total_fee").val(0);
        }
        else
        {
            var total_fee = main_fee - discount_ammount;

            $("#total_fee").val(total_fee);
        }

    });



    
        
    


   });


   $(document).ready(function(){

    $("#discount_ammount").on('keyup',function(){

        var main_fee = parseInt($("#main_fee").val());

        var discount_ammount = parseInt($("#discount_ammount").val());

        var discount_percentage = (discount_ammount/main_fee * 100);

        var sign = "%";

        $("#discount_per").val(discount_percentage.toFixed(0)+sign);

        // alert();

    });

   });




   

</script>


<script type="text/javascript">
    $(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script>



<script type="text/javascript">
$(document).ready(function(){


$("#student_id").on('change',function(){

// alert();

var std_id = $(this).val();

// alert(std_id);

if(std_id == " ")
{

}
else
{
    $.ajax({

            headers : {
                'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
            },

            url : '<?php echo e(url('getTrainer')); ?>',

            type : 'POST',

            data : {

                id:std_id,
            },

            success : function(data)
            {
                // alert(data);
                // $("#result").html(data);
                $("#course_detail").html(data);
            } 
    });
}

});

});

</script>


<script type="text/javascript">
$(document).ready(function(){


$("#std_id").on('change',function(){

// alert();

var std_id = $(this).val();

// alert(std_id);

if(std_id == " ")
{

}
else
{
    $.ajax({

            headers : {
                'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
            },

            url : '<?php echo e(url('getstdTrainer')); ?>',

            type : 'POST',

            data : {

                id:std_id,
            },

            success : function(data)
            {
                // alert(data);
                // $("#result").html(data);
                $("#course_detail").html(data);
            } 
    });
}

});

});

</script>

<script type="text/javascript">
    $(document).ready(function(){

        $("#studentId").on('change',function(){
            var std_id = $(this).val();
            // alert(std_id);
            if(std_id == 0)
            {
                alert('Select a Student');
            }
            else
            {
                $.ajax({

                headers : {
                    'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                },

                url : '<?php echo e(url('getStudentFee')); ?>',

                type : 'POST',

                data : {

                    id:std_id,
                },

                success : function(data)
                {
                    $("#totaldue").val(data);
                } 
        });
            }
        });

    });
</script>

<script type="text/javascript">
    
    $(document).ready(function(){

        $('#collection_ammount').on('keyup',function(){

            var collection_ammount = parseInt($(this).val());
            var due_ammount = parseInt($("#totaldue").val());
            // alert(due_ammount);

            if(collection_ammount > due_ammount)
            {
                $("#collection_ammount").val(0);
            }
            else
            {
                var new_due = due_ammount - collection_ammount;

                $("#new_due").val(new_due);
            }

        });

    });

</script>

<script type="text/javascript">
    
$(document).ready(function(){

    $('#daily').hide();
    $('#date_to_date').hide();
    $('#date_to_date1').hide();
    $('#monthly').hide();
    $('#monthly1').hide();
    $('#yearly').hide();

    $("#report_type").on('change',function(){

        var type = $(this).val();

        // alert(type);

        if(type == 'All')
        {
            $('#daily').hide();
            $('#date_to_date').hide();
            $('#date_to_date1').hide();
            $('#monthly').hide();
            $('#monthly1').hide();
            $('#yearly').hide();
        }
        else if(type == 'Daily')
        {
            $('#daily').fadeIn();
            $('#date_to_date').hide();
            $('#date_to_date1').hide();
            $('#monthly').hide();
            $('#monthly1').hide();
            $('#yearly').hide();
        }
        else if(type == 'Date_to_Date')
        {
            $('#daily').hide();
            $('#date_to_date').fadeIn();
            $('#date_to_date1').fadeIn();
            $('#monthly').hide();
            $('#monthly1').hide();
            $('#yearly').hide();
        }
        else if(type == 'Monthly')
        {
            $('#daily').hide();
            $('#date_to_date').hide();
            $('#date_to_date1').hide();
            $('#monthly').fadeIn();
            $('#monthly1').fadeIn();
            $('#yearly').hide();
        }
        else if(type == 'Yearly')
        {
            $('#daily').hide();
            $('#date_to_date').hide();
            $('#date_to_date1').hide();
            $('#monthly').hide();
            $('#monthly1').hide();
            $('#yearly').fadeIn();
        }

    });

});

</script>



<script type="text/javascript">
    
//     instance = new dtsel.DTS('input[name="dateTimePicker"]',  {
//   showTime: true
// });

instance = new dtsel.DTS('input[id="dateTimePicker"]',  {
  showTime: false,
  showDate: true
});

instance = new dtsel.DTS('input[id="dateTimePicker"]',  {
  dateFormat: "yyyy-mm-dd",
})

</script>
<script type="text/javascript">
    
//     instance = new dtsel.DTS('input[name="dateTimePicker"]',  {
//   showTime: true
// });

instance = new dtsel.DTS('input[id="dateTimePicker1"]',  {
  showTime: false,
  showDate: true
});

instance = new dtsel.DTS('input[id="dateTimePicker1"]',  {
  dateFormat: "yyyy-mm-dd",
})

</script>
<script type="text/javascript">
    
//     instance = new dtsel.DTS('input[name="dateTimePicker"]',  {
//   showTime: true
// });

instance = new dtsel.DTS('input[id="dateTimePicker2"]',  {
  showTime: false,
  showDate: true
});

instance = new dtsel.DTS('input[id="dateTimePicker2"]',  {
  dateFormat: "yyyy-mm-dd",
})

</script>



<script type="text/javascript">
    
    $(document).ready(function(){

        $('#loading').hide();

        function loadCurrentData()
        {
            $.ajax({
                headers : {
                    'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                },

                url :'<?php echo e(url('getCurrentData')); ?>',

                type : 'POST',

                success : function(data)
                {
                    $('#current_data').html(data);
                }
            });
        }

        loadCurrentData();

        $('#add_current').on('click',function(e){

            e.preventDefault();

            var des = $('#description').val();
            var amm = $('#ammount').val();
            var session = $('#session_id').val();

            
                    $.ajax({

                    


                    headers : {
                        'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                    },

                    url : '<?php echo e(url('storeCurrent')); ?>',

                    type : 'POST',

                    data : 
                    {
                        description:des,ammount:amm,session_id:session
                    },

                    success: function(data)
                    {
                        // alert(data);

                        if(data == 1)
                        {
                            $('#description').val("");
                            $('#ammount').val("");
                            loadCurrentData(); 
                        }
                        else
                        {
                            alert(0);
                        }
                    }

                });
            
            

        });




    });

</script>

<script type="text/javascript">
    function DeleteCurrent($id)
    {
        $(document).on('click','#deleteCurrent_'+$id,function(){

            var getId = $('#deleteCurrent_'+$id).attr('name');
            // alert(getId);
            var element = this;

            $.ajax({
                headers : {
                    'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                },
                url : '<?php echo e(url('deleteCurrentData')); ?>',

                type : 'POST',

                data : {id:getId},

                success : function(data)
                {
                    if(data == 1)
                    {
                        $(element).closest('tr').fadeOut();
                    }
                    else
                    {
                        alert('Something Went Wrong!');
                    }
                }
            })

        });
    }
</script>


<script type="text/javascript">
    
    $(document).ready(function(){

        $('#trainerId').on('change',function(){

            var trainer_id = $(this).val();

            if(trainer_id == "0")
            {
                alert('Please Select A Trainer');
                $('#totalSalary').val(0);
            }
            else
            {
                $.ajax({


                    headers : {
                        'X-CSRF-TOKEN' : "<?php echo e(csrf_token()); ?>"
                    },

                    url : '<?php echo e(url('getTrainerSalary')); ?>',

                    type : 'POST',

                    data : {id:trainer_id},

                    success : function(data)
                    {
                        $('#totalSalary').val(data);
                    }

                });
            }

        });


    $("#selectYear").on('change',function(){

        var year = $(this).val();
        // alert(year);

        $.ajax({

            headers : 
            {
                'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>'
            },

            url : '<?php echo e(url('getYearData')); ?>',

            type : 'POST',

            data : {yearly:year},

            success:function(data)
            {
                $("#SalaryData").html(data);
            }

        });

    }); 

    });


</script>


<script type="text/javascript">
    $(document).ready(function() {
  $('#description').summernote();
});
</script>

</body>

<!-- Mirrored from demo.dashboardpack.com/admindek-html/default/dashboard-crm.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 14 Jun 2022 06:17:14 GMT -->
</html><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/Layouts/footer.blade.php ENDPATH**/ ?>