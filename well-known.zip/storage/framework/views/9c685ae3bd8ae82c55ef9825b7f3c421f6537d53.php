<?php if($course_info): ?>
<div class="row">
<!-- <span class="col-12" style="color:red">***Select Only One Trainer From Each Course***</span> -->
<?php $__currentLoopData = $course_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show_course_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-6">
    <div class="course_box">
        <div class="title">
            <!-- <input type="text" name="course_id[]" value="<?php echo e($show_course_info->id); ?>" hidden> -->
            <h5><?php echo e($show_course_info->course_name); ?></h5>
        </div>
        <div class="trainers">
            <div class="trainer_single">
                <?php 
                $trainer_info = DB::table('trainer_appoint')
                                ->join('trainer_info','trainer_info.id','trainer_appoint.trainer_id')
                                ->where('student_id',$id)
                                ->get();

               
                ?>
                <?php if($trainer_info): ?>
                <?php $__currentLoopData = $trainer_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show_trainer_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($show_course_info->id == $show_trainer_info->course_id): ?>
                <li>
                    <img src="<?php echo e(asset('public/Backend')); ?>/Images/trainerImage/<?php echo e($show_trainer_info->image); ?>" style="height:50px;width:50px;border-radius: 100px;"> <span><?php echo e($show_trainer_info->trainer_name); ?></span>   <i style="color:green" class="fa fa-check-circle"></i>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="submit" style="margin-top: 20px;">
<a href="<?php echo e(url('deleteAppTrainer')); ?>/<?php echo e($id); ?>" class="btn btn-outline-danger">Delete Appointed Trainer</a>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/User/StudentInfo/stdtrainer_search_result.blade.php ENDPATH**/ ?>