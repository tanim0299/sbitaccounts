<?php if($trainer): ?>
<?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showtrainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-6 col-md-6 col-12">
    <div class="trainer_single-box" style="margin-top: 20px;">
        <div class="box-header bg-success">
            <div class="row">
                <div class="col-6">
                    <div class="trainer_image">
                        <img src="<?php echo e(asset('public')); ?>/Backend/Images/trainerImage/<?php echo e($showtrainer->image); ?>">
                    </div>
                    <div class="trainer_name">
                         <h3><?php echo e($showtrainer->trainer_name); ?></h3>
                    </div>
                    <div class="trainer_name">
                         <span><?php echo e($showtrainer->designation); ?></span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="trainer-salary" style="text-align:right;">
                        <label>Salary Info For This Year</label>
                        <span>Salary Ammount : <?php echo e($showtrainer->salary); ?>/-</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="box-footer">
            <table class="table table-striped table-bordered" style="margin-bottom: 0px;">
                <tr>
                    <th>Sl</th>
                    <th>Month</th>
                    <th>Year</th>
                    <th>Given Ammount</th>
                    <th>Action</th>
                </tr>
                <?php if($salary_info): ?>
                <?php $__currentLoopData = $salary_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showSalary_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($showSalary_info->trainer_id == $showtrainer->id): ?>
                <?php if($showSalary_info->year == $year): ?>
                <tr>
                    <td><?php echo e($sl++); ?></td>
                    <td><?php echo e($showSalary_info->month); ?></td>
                    <td><?php echo e($showSalary_info->year); ?></td>
                    <td><?php echo e($showSalary_info->ammount); ?>/-</td>
                    <td>
                        <a href="<?php echo e(url('deleteSalary')); ?>/<?php echo e($showSalary_info->id); ?>" class="btn btn-outline-danger">Delete</a>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/User/Salary/year_wise_salary.blade.php ENDPATH**/ ?>