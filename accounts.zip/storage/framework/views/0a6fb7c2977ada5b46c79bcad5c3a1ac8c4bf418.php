<!-- <?php if($total_value): ?> -->
<div class="input-single-box">
    <label>Course Fee</label>
    <input type="text" name="fee" class="form-control" readonly id="main_fee" value="<?php echo e($total_value); ?>">
</div>
<!-- <?php endif; ?> --><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/User/StudentInfo/course_fee.blade.php ENDPATH**/ ?>