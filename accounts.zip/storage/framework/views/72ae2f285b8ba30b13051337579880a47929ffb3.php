

<?php $__env->startSection('body'); ?>
<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<!-- <i class="feather icon-home bg-c-blue"></i> -->
<div class="d-inline">
<h5>View Trainer</h5>
<!-- <span>This Is SBIT Dashboard</span> -->
<div class="links" style="margin-top: 20px;">
    <a href="<?php echo e(url('addTrainer')); ?>" class="btn btn-outline-info">Add Trainer</a>
</div>
</div>
</div>
</div>

</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">
 
 <!-- //body content goes here -->
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>View Trainer</h5>
        </div>
        <div class="card-block">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('success')); ?></strong>
                </div>
                <?php elseif(Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('error')); ?></strong>
                </div>
                <?php endif; ?>

            <div class="dt-responsive table-responsive">
                <table class="table table-striped table-bordered nowrap dataTable" id="order-table">
                    <thead>
                        <tr>
                            <th>Sl</th>
                            <th>Name</th>
                            <th>Designation</th>
                            <th>Salary</th>
                            <th>Course</th>
                            <th>Phone</th>
                            <th>Adress</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sl++); ?></td>
                            <td><?php echo e($showdata->trainer_name); ?></td>
                            <td><?php echo e($showdata->designation); ?></td>
                            <td><?php echo e($showdata->salary); ?></td>
                            <td><?php echo e($showdata->course_name); ?></td>
                            <td><?php echo e($showdata->phone); ?></td>
                            <td><?php echo e($showdata->adress); ?></td>
                            <td>
                            	<img src="<?php echo e(asset('public/Backend')); ?>/Images/trainerImage/<?php echo e($showdata->image); ?>" height="70px" width="70px" style="border-radius:100px;">
                            </td>
                            <td>
                                <a href="<?php echo e(url('editTrainer')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-info">Edit</a>
                                <a href="<?php echo e(url('deleteTrainer')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
 </div>
 <!-- //body content goes here -->

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/User/TrainerInfo/view_trainer.blade.php ENDPATH**/ ?>