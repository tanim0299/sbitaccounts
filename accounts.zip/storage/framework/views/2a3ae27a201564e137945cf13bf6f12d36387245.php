

<?php $__env->startSection('body'); ?>
<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<!-- <i class="feather icon-home bg-c-blue"></i> -->
<div class="d-inline">
<h5>View Expense</h5>
<!-- <span>This Is SBIT Dashboard</span> -->
<div class="links" style="margin-top: 20px;">
    <a href="<?php echo e(url('/add_expense')); ?>" class="btn btn-outline-info">Add Expense</a>
</div>
</div>
</div>
</div>

</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">
 
 <!-- //body content goes here -->
 <div class="form-body">
    <div class="card">
        <div class="card-header">
             <h5>View Expense</h5>
        </div>
        <div class="card-block">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('success')); ?></strong>
                </div>
                <?php elseif(Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e(Session::get('error')); ?></strong>
                </div>
                <?php endif; ?>

            <div class="dt-responsive table-responsive">
                <table class="table table-striped table-bordered nowrap dataTable" id="order-table">
                    <thead>
                        <tr>
                            <th>Sl</th>
                            <th>Date</th>
                            <th>Expense Type</th>
                            <th>Ammount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $showdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sl++); ?></td>
                            <td><?php echo e($showdata->date); ?></td>
                            <?php
                            if($showdata->expense_title == 'Salary Expense')
                            {
                                $details = DB::table('salary_info')
                                           ->join('trainer_info','salary_info.trainer_id','=','trainer_info.id')
                                           ->where('salary_info.expense_id',$showdata->id)
                                           ->select('salary_info.month','salary_info.year','trainer_info.trainer_name')
                                           ->first();
                            }
                            ?>
                            <?php if($details): ?>
                            <td><?php echo e($showdata->expense_title); ?> ( <?php echo e($details->trainer_name); ?> - <?php echo e($details->month); ?> - <?php echo e($details->year); ?> )</td>
                            <?php else: ?>
                            <td><?php echo e($showdata->expense_title); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($showdata->ammount); ?></td>
                            <td>
                                <a href="<?php echo e(url('edit_expense')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-info">Edit</a>
                                <a href="<?php echo e(url('deleteExpense')); ?>/<?php echo e($showdata->id); ?>" class="btn btn-outline-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
 </div>
 <!-- //body content goes here -->

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbitaccounts\resources\views/Backend/User/ExpenseInfo/view_expense.blade.php ENDPATH**/ ?>